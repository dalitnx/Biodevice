*************************************
Hibou - DHL Partner Shipping Accounts
*************************************

Adds DHL shipping accounts.

For more information and add-ons, visit `Hibou.io <https://hibou.io/>`_.


=============
Main Features
=============

* Adds DHL to the delivery type selection field.
* Validates entered DHL account numbers are the correct length.

.. image:: https://user-images.githubusercontent.com/15882954/41176760-825c6802-6b16-11e8-91b6-188b32146626.png
    :alt: 'Register Payment Detail'
    :width: 988
    :align: left

=======
License
=======

Please see `LICENSE <https://github.com/hibou-io/hibou-odoo-suite/blob/11.0/LICENSE>`_.

Copyright Hibou Corp. 2018
