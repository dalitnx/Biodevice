from odoo.tests import common


class TestHelpdesk(common.TransactionCase):

    # We need to test Stage, Ticket, Server, and Filter Classes
    # We created a couple fields per model and a couple methods
    # for our functionality implementation

    def setUp(self):
        pass

    def test_helpdesk_filter(self):
        pass