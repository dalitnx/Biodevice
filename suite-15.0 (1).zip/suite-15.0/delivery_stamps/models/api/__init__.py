# -*- coding: utf-8 -*-
"""
    stamps
    ~~~~~~

    Stamps.com API.

    :copyright: 2014 by Jonathan Zempel.
    :license: BSD, see LICENSE for more details.
"""

__author__ = "Jonathan Zempel"
__license__ = "BSD"
__version__ = "0.9.1"
