# Part of Hibou Suite Professional. See LICENSE_PROFESSIONAL file for full copyright and licensing details.

# Moved to l10n_us_hr_payroll_401k_params
