from . import hr_attendance
from . import hr_contract
from . import hr_payslip
