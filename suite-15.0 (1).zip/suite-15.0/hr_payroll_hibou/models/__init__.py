from . import browsable_object
from . import hr_contract
from . import hr_payslip
from . import hr_salary_rule
from . import res_config_settings
from . import update
