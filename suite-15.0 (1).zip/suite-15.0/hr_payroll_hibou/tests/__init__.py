# Part of Hibou Suite Professional. See LICENSE_PROFESSIONAL file for full copyright and licensing details.

from . import common

from . import test_contract_wage_type
from . import test_special
from . import test_update
