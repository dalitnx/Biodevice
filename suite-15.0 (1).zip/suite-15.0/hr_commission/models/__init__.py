# Part of Hibou Suite Professional. See LICENSE_PROFESSIONAL file for full copyright and licensing details.

from . import account
from . import commission
from . import hr
from . import partner
from . import res_company
from . import res_config_settings
