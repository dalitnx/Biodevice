from . import hr_contract
from . import hr_payslip
from . import hr_work_entry
from . import resource_calendar
