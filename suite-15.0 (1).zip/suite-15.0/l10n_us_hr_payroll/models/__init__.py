# Part of Hibou Suite Professional. See LICENSE_PROFESSIONAL file for full copyright and licensing details.

from . import hr_contract
from . import hr_payslip
from . import update
from . import us_payroll_config
