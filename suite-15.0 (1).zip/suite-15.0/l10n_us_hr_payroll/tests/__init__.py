# Part of Hibou Suite Professional. See LICENSE_PROFESSIONAL file for full copyright and licensing details.

# Tests moved to `l10n_us_hr_payroll_params`
# common remains for site specific tests

from . import common
