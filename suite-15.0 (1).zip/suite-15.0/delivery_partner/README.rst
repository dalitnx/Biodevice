*********************************
Hibou - Partner Shipping Accounts
*********************************

Records shipping account numbers on partners.

For more information and add-ons, visit `Hibou.io <https://hibou.io/>`_.


=============
Main Features
=============

* New model: Customer Shipping Account
* Includes manager-level access permissions.

.. image:: https://user-images.githubusercontent.com/15882954/41176601-e40f8558-6b15-11e8-998e-6a7ee5709c0f.png
    :alt: 'Register Payment Detail'
    :width: 988
    :align: left


=======
License
=======

Please see `LICENSE <https://github.com/hibou-io/hibou-odoo-suite/blob/11.0/LICENSE>`_.

Copyright Hibou Corp. 2018
