***************************************
Hibou - UPS Partner Shipping Accounts
***************************************

Adds UPS shipping accounts.

For more information and add-ons, visit `Hibou.io <https://hibou.io/>`_.


=============
Main Features
=============

* Adds UPS to the delivery type selection field.
* Adds new required field of UPS Account ZIP.
* Validates entered UPS account numbers are the correct length.

.. image:: https://user-images.githubusercontent.com/15882954/41176879-e7dc5a66-6b16-11e8-82a2-9b6cd0c909fd.png
    :alt: 'Register Payment Detail'
    :width: 988
    :align: left

=======
License
=======

Please see `LICENSE <https://github.com/hibou-io/hibou-odoo-suite/blob/11.0/LICENSE>`_.

Copyright Hibou Corp. 2018
